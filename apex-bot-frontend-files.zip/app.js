const $ = (id) => document.getElementById(id);

const state = {
  running: false,
  pollTimer: null
};

function log(message) {
  const box = $("log");
  const time = new Date().toLocaleTimeString();
  box.textContent += `\n[${time}] ${message}`;
  box.scrollTop = box.scrollHeight;
}

function setStatus(online) {
  $("statusDot").className = `dot ${online ? "online" : "offline"}`;
  $("statusText").textContent = online ? "Online" : "Offline";
}

function setRunning(running) {
  state.running = running;
  $("startBtn").disabled = running;
  $("stopBtn").disabled = !running;
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: { "Content-Type": "application/json" },
    ...options
  });

  let data = {};
  try {
    data = await response.json();
  } catch (_) {}

  if (!response.ok) {
    throw new Error(data.error || `Request failed: ${response.status}`);
  }

  return data;
}

async function refreshStatus() {
  try {
    const data = await api("/api/status");

    setStatus(Boolean(data.connected));
    setRunning(Boolean(data.running));

    if (data.balance !== undefined) {
      $("balance").textContent = `$${Number(data.balance).toFixed(2)}`;
    }

    if (data.currentStake !== undefined) {
      $("stake").textContent = `$${Number(data.currentStake).toFixed(2)}`;
    }

    if (data.profit !== undefined) {
      $("profit").textContent = `$${Number(data.profit).toFixed(2)}`;
    }

    $("activeTrade").textContent = data.activeTrade
      ? "Running"
      : "None";
  } catch (error) {
    setStatus(false);
  }
}

async function startBot() {
  const initialStake = Number($("initialStake").value);
  const maxStake = Number($("maxStake").value);
  const takeProfit = Number($("takeProfit").value);

  if (!Number.isFinite(initialStake) || initialStake <= 0) {
    log("Invalid initial stake.");
    return;
  }

  if (!Number.isFinite(maxStake) || maxStake < initialStake) {
    log("Maximum stake must be greater than or equal to initial stake.");
    return;
  }

  try {
    await api("/api/bot/start", {
      method: "POST",
      body: JSON.stringify({
        initialStake,
        maxStake,
        takeProfit
      })
    });

    setRunning(true);
    log(`Bot started | Base stake $${initialStake} | Max stake $${maxStake}`);
    await refreshStatus();
  } catch (error) {
    log(`Start error: ${error.message}`);
  }
}

async function stopBot() {
  try {
    await api("/api/bot/stop", {
      method: "POST"
    });

    setRunning(false);
    log("Bot stopped.");
    await refreshStatus();
  } catch (error) {
    log(`Stop error: ${error.message}`);
  }
}

$("startBtn").addEventListener("click", startBot);
$("stopBtn").addEventListener("click", stopBot);

$("clearLog").addEventListener("click", () => {
  $("log").textContent = "Activity log cleared.";
});

refreshStatus();
state.pollTimer = setInterval(refreshStatus, 3000);
