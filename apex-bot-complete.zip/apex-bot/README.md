# Apex Bot
Complete Deriv WebSocket bot.

Strategy:
- Volatility 100 Index (1HZ100V)
- Even last digit -> Rise/CALL
- Duration: 1 tick
- $1 base stake
- Win -> reset to $1
- Loss -> double stake
- MAX_STAKE caps exposure
- One active contract at a time

Setup:
1. Install Node.js 18+.
2. Put Deriv credentials in .env.
3. Run: npm install
4. Run: npm start

Use DEMO credentials first. Martingale does not guarantee recovery or profit and can rapidly increase losses. Keep .env private.
