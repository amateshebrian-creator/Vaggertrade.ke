require("dotenv").config();
const WebSocket = require("ws");

const API="https://api.derivws.com";
const APP_ID=process.env.DERIV_APP_ID;
const TOKEN=process.env.DERIV_TOKEN;
const ACCOUNT_ID=process.env.DERIV_ACCOUNT_ID;
const SYMBOL="1HZ100V";
const BASE_STAKE=1;
let current_stake=BASE_STAKE;
const MAX_STAKE=Number(process.env.MAX_STAKE||32);

let ws, wsUrl, reqId=1, tradeInProgress=false, activeContractId=null;
const pending=new Map();

function log(x){console.log(`[${new Date().toISOString()}] ${x}`);}
function send(request){
  return new Promise((resolve,reject)=>{
    if(!ws||ws.readyState!==WebSocket.OPEN)return reject(new Error("WebSocket not connected"));
    const id=reqId++;
    const timer=setTimeout(()=>{pending.delete(id);reject(new Error("Request timeout"));},15000);
    pending.set(id,{resolve,reject,timer});
    ws.send(JSON.stringify({...request,req_id:id}));
  });
}

async function getWsUrl(){
  if(!APP_ID||!TOKEN||!ACCOUNT_ID) throw new Error("Set DERIV_APP_ID, DERIV_TOKEN and DERIV_ACCOUNT_ID in .env");
  const r=await fetch(`${API}/trading/v1/options/accounts/${ACCOUNT_ID}/otp`,{
    method:"POST",
    headers:{Authorization:`Bearer ${TOKEN}`,"Deriv-App-ID":APP_ID,"Content-Type":"application/json"}
  });
  if(!r.ok) throw new Error(`OTP failed: ${r.status} ${await r.text()}`);
  const j=await r.json();
  if(!j.data?.url) throw new Error("No authenticated WebSocket URL returned");
  return j.data.url;
}

function lastDigit(q){
  const d=String(q).replace(/\D/g,"");
  return d.length?Number(d.at(-1)):null;
}

function finalResult(c){
  const s=String(c.status||"").toLowerCase();
  log(`FINAL | contract=${c.contract_id} | ${s} | profit=${c.profit}`);
  if(s==="won"){
    current_stake=BASE_STAKE;
    log(`WIN -> next stake $${current_stake}`);
  }else if(s==="lost"){
    const next=current_stake*2;
    if(next>MAX_STAKE){
      log(`LOSS -> $${next} exceeds MAX_STAKE $${MAX_STAKE}; resetting to $${BASE_STAKE}`);
      current_stake=BASE_STAKE;
    }else{
      current_stake=next;
      log(`LOSS -> next stake $${current_stake}`);
    }
  }
  tradeInProgress=false;
  activeContractId=null;
}

async function buyRise(){
  if(tradeInProgress)return;
  tradeInProgress=true;
  const stake=current_stake;
  try{
    const p=await send({
      proposal:1,amount:stake,basis:"stake",contract_type:"CALL",
      currency:process.env.CURRENCY||"USD",duration:1,duration_unit:"t",
      underlying_symbol:SYMBOL
    });
    if(p.error)throw new Error(p.error.message);
    const id=p.proposal?.id, price=Number(p.proposal?.ask_price);
    if(!id||!Number.isFinite(price))throw new Error("Invalid proposal");
    const b=await send({buy:id,price});
    if(b.error)throw new Error(b.error.message);
    activeContractId=b.buy?.contract_id;
    if(!activeContractId)throw new Error("No contract ID returned");
    log(`BOUGHT | Rise/CALL | 1 tick | stake $${stake} | contract ${activeContractId}`);
    await send({proposal_open_contract:1,contract_id:activeContractId,subscribe:1});
  }catch(e){
    log(`TRADE ERROR | ${e.message}`);
    tradeInProgress=false;
    activeContractId=null;
  }
}

function message(m){
  if(m.req_id&&pending.has(m.req_id)){
    const p=pending.get(m.req_id); pending.delete(m.req_id); clearTimeout(p.timer);
    p.resolve(m);
  }
  if(m.msg_type==="tick"&&m.tick){
    const d=lastDigit(m.tick.quote);
    log(`TICK | ${m.tick.quote} | last digit ${d} | stake $${current_stake}`);
    if(d!==null&&d%2===0&&!tradeInProgress) void buyRise();
  }
  if(m.msg_type==="proposal_open_contract"&&m.proposal_open_contract){
    const c=m.proposal_open_contract;
    if(c.contract_id===activeContractId&&c.is_sold) finalResult(c);
  }
  if(m.error)log(`DERIV ERROR | ${m.error.message}`);
}

function connect(){
  ws=new WebSocket(wsUrl);
  ws.on("open",async()=>{
    log("Connected to Deriv");
    try{await send({ticks:SYMBOL,subscribe:1});log(`Subscribed to ${SYMBOL}`);}
    catch(e){log(`Subscription error | ${e.message}`);}
  });
  ws.on("message",raw=>{try{message(JSON.parse(raw.toString()));}catch(e){log(`JSON error | ${e.message}`);}});
  ws.on("error",e=>log(`WebSocket error | ${e.message}`));
  ws.on("close",()=>{
    log("Disconnected; reconnecting...");
    for(const [id,p] of pending){clearTimeout(p.timer);p.reject(new Error("Disconnected"));pending.delete(id);}
    setTimeout(connect,3000);
  });
}

(async()=>{
  log("Apex Bot starting");
  log(`Strategy: even last digit -> 1-tick Rise; Martingale $1 base, max $${MAX_STAKE}`);
  wsUrl=await getWsUrl();
  connect();
})().catch(e=>{log(`Startup error | ${e.message}`);process.exit(1);});

process.on("SIGINT",()=>{if(ws)ws.close();process.exit(0);});
